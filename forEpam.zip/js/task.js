function child(word){

    var wordWithoutSpaces = word.replace(/\s+/g, '');
    var parent = document.getElementById('list');
    var equalChild = parent.getElementsByTagName('*');
    var reg = new RegExp(wordWithoutSpaces , 'i');

    for(var i = 0; i < equalChild.length; i++){

        if(reg.exec('' + equalChild[i].innerHTML.replace(/\s+/g, '')) != null){
            equalChild[i].style.display = "inherit";
        }else if(reg.exec('' + equalChild[i].innerHTML.replace(/\s+/g, '')) == null){
            equalChild[i].style.display = "none";
        }

    }
}

function opacityUl(){
    document.getElementById('list').style.opacity = "0";
}

function deleteLi(numID){

    var numId = numID;
    var heightOne = document.getElementById('leftColumn').offsetHeight;
    var heightTwo = document.getElementById('rightColumn').offsetHeight;
    var liToDel = document.getElementById("" + numId);

    if(467 < document.getElementById('list').offsetHeight) {
        document.getElementById('rightColumn').style.height = heightTwo - liToDel.offsetHeight - 200 + "px";
        document.getElementById('leftColumn').style.height = heightOne - liToDel.offsetHeight - 200 + "px";
    }
    if(document.getElementById('list').childNodes.length == 2){
        document.getElementById('list').style.opacity = "0";
    }

    liToDel.parentNode.removeChild(liToDel);
}



function equalColumnsHeight(){

    var columnRightHeight = document.getElementById('rightColumn').offsetHeight;
    var text, numbers;
    var patternInput = /^\d+$/;
    var newLi = document.createElement('li');

    text = document.getElementById('text').value;
    numbers = document.getElementById('numbers').value;
    newLi.setAttribute('id', '' + numbers);
    newLi.setAttribute('onclick', 'deleteLi('+ numbers +')');
    newLi.innerHTML = "" + text + numbers;
    document.getElementById('list').style.marginBottom = "105px";

    if(numbers.match(patternInput) != null){
        document.getElementById('list').style.opacity = "1";
        document.getElementById('list').appendChild(newLi);
        var heightElement = document.getElementById('list').offsetHeight;

        if(columnRightHeight < heightElement){
            var res = heightElement - columnRightHeight + 200;
            document.getElementById('rightColumn').style.height = columnRightHeight + res +  "px";
            document.getElementById('leftColumn').style.height = columnRightHeight + res + "px";
        }
    }else{
        alert("�� �����");
    }
}